import logging
import io
from flask import Request, Response
from backend.routes_api import api_bp
from flask import Flask

# Create Flask application for Advanced I/O function
app = Flask(__name__)
app.register_blueprint(api_bp)

def handler(request: Request):
    """Catalyst Advanced I/O function handler for Wallet Note."""
    with app.request_context(request.environ):
        try:
            response = app.full_dispatch_request()
            return response
        except Exception as e:
            logging.error(f"Error handling request: {e}")
            return Response(f"Internal Server Error: {e}", status=500)
